# 🕌 বাঁশকান্দি মাদ্রাসা আযান — Production Source

`com.baskandi.azan` — বাংলা আযান ও নামাজের সময়সূচির Flutter Android project।

## লোকেশন

### 🇮🇳 বাঁশকান্দি / শিলচর, কাছাড়
- Latitude: `24.8333`
- Longitude: `92.7789`
- Time zone: `Asia/Kolkata`
- Calculation: Karachi
- Asr: Hanafi

### 🇰🇼 সালমিয়া / হাওয়ালি
- Latitude: `29.3333`
- Longitude: `48.0833`
- Time zone: `Asia/Kuwait`
- Calculation: Umm Al-Qura

## Production features

- ৫ ওয়াক্তের astronomical prayer-time calculation
- শিলচর: Karachi + Hanafi
- সালমিয়া: Umm Al-Qura
- GPS থেকে বর্তমান Latitude/Longitude নেওয়া
- ফোনের বর্তমান IANA timezone নেওয়ার চেষ্টা (`flutter_timezone`)
- GPS mode চালু/বন্ধ করা যায়
- GPS না চললে নির্দিষ্ট দুই শহরের মধ্যে দ্রুত পরিবর্তন
- পরবর্তী ওয়াক্তের HH:MM:SS countdown
- প্রতিটি ওয়াক্ত আলাদা ON/OFF
- প্রতিটি ওয়াক্তে -১০ থেকে +১০ মিনিট manual adjustment
- ৭ দিনের prayer schedule
- সেহরি: ফজরের ১০ মিনিট আগে reminder
- ইফতার: মাগরিবের ১ মিনিট আগে reminder
- Android 13+ notification permission
- Android 12+ exact alarm permission
- Android reboot / package-replaced notification receiver
- `exactAllowWhileIdle` scheduling
- কাস্টম Android notification sound resource support
- অ্যাপের ভিতরে `audioplayers` দিয়ে অনুমোদিত azan.mp3 preview
- সম্পূর্ণ বাংলা UI
- Play Store AAB signing configuration template

## Build

```bash
flutter clean
flutter pub get
flutter run
```

Release APK:
```bash
flutter build apk --release
```

Play Store AAB:
```bash
flutter build appbundle --release
```

## গুরুত্বপূর্ণ Android বিষয়

Android 12+ Exact Alarm permission ব্যবহারকারীকে Settings-এ অনুমতি দিতে বলতে পারে। Android 13+ notification permission-ও প্রয়োজন। ফোনের battery optimization যদি scheduled notification আটকে দেয়, ব্যবহারকারীকে এই অ্যাপের battery usage-এ unrestricted/allow background activity দিতে হতে পারে।

ফোন সম্পূর্ণ বন্ধ থাকা অবস্থায় কোনো অ্যাপ নিজে থেকে অডিও বাজাতে পারে না। ফোন চালু হয়ে গেলে Android-এর boot receiver এবং notification plugin-এর stored schedule পুনরায় সক্রিয় করার ব্যবস্থা আছে।

## কাস্টম আযান অডিও

এই source-এ কোনো কপিরাইটযুক্ত আযান recording নেই। Build/test যাতে asset missing error না দেয়, একটি **১-সেকেন্ডের নীরব placeholder** রাখা হয়েছে। এটি প্রকৃত আযান নয়।

আপনার নিজের/অনুমোদিত MP3 একই নামে দুই জায়গায় প্রতিস্থাপন করুন:

```text
assets/audio/azan.mp3
android/app/src/main/res/raw/azan.mp3
```

Android resource filename অবশ্যই lowercase/সংখ্যা/underscore-এ রাখতে হবে।

## Signing

`android/key.properties.example` কপি করে `android/key.properties` বানান এবং নিজের keystore তথ্য দিন। নিজের signing key ছাড়া Play Store-এ production release publish করবেন না।

## ১৬ আগস্ট ২০২৬ reference timetable

আপনার দেওয়া সময়গুলো test/reference হিসেবে রাখা হয়েছে, স্থায়ী timetable হিসেবে নয়:

- ফজর 03:56 AM
- যোহর 11:47 AM
- আসর 04:24 PM
- মাগরিব 06:16 PM
- ইশা 07:36 PM

বর্তমান source এগুলোকে স্থায়ী ১২-মাসের সময় হিসেবে hard-code করে না। তারিখ, coordinates এবং calculation parameters থেকে prayer times তৈরি হয়। স্থানীয় মসজিদের verified timetable-এর সঙ্গে manual adjustment ব্যবহার করুন।

## Accuracy note

Astronomical calculation এবং স্থানীয় মসজিদের ঘোষিত আযান/জামাতের সময় এক জিনিস নয়। Coordinates, calculation method, local convention এবং mosque-specific adjustment-এর কারণে পার্থক্য হতে পারে। তাই “১০০% নিখুঁত” দাবি না করে স্থানীয় মাইকের সময়কে চূড়ান্ত স্থানীয় reference হিসেবে বিবেচনা করা উচিত।
