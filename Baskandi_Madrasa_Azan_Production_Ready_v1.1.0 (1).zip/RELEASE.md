# Play Store / Production release checklist

## 1) Install dependencies
```bash
flutter clean
flutter pub get
```

## 2) Add your own signing key
Create a keystore (example):
```bash
keytool -genkeypair -v -keystore baskandi-upload-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias baskandi
```
Copy it somewhere safe and create `android/key.properties` from `android/key.properties.example`.

## 3) Build AAB
```bash
flutter build appbundle --release
```
Output:
`build/app/outputs/bundle/release/app-release.aab`

## 4) Before publishing
- Replace the placeholder `assets/audio/azan.mp3` and `android/app/src/main/res/raw/azan.mp3` with your own/authorized azan recording.
- Test notification permission on Android 13+.
- Test Exact Alarm permission on Android 12+.
- Test GPS denied / GPS off / denied-forever cases.
- Test phone reboot and battery optimization on the target devices.
- Verify all prayer times against the local mosque timetable before public release.
- Keep your upload keystore and passwords backed up securely.

The source deliberately does not include a real azan recording or a developer signing key.
