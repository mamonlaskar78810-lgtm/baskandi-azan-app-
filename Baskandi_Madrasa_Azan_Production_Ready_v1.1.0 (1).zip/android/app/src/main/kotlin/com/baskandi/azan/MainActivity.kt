package com.baskandi.azan

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
