import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:adhan/adhan.dart';
import 'package:flutter/material.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart' as intl_data;
import 'package:shared_preferences/shared_preferences.dart';
import 'services/alarm_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await intl_data.initializeDateFormatting('bn');
  final zone = await _deviceTimezone();
  await AlarmService.initialize(localTimezone: zone);
  runApp(const BaskandiAzanApp());
}

Future<String> _deviceTimezone() async {
  try {
    final dynamic info = await FlutterTimezone.getLocalTimezone();
    if (info is String) return info;
    final dynamic name = info.name;
    if (name is String && name.isNotEmpty) return name;
  } catch (_) {}
  return 'UTC';
}

final CalculationParameters _silcharParams =
    CalculationMethod.karachi.getParameters()..madhab = Madhab.hanafi;
final CalculationParameters _kuwaitParams =
    CalculationMethod.umm_al_qura.getParameters()..madhab = Madhab.shafi;

class AppLocation {
  final String id, name, subtitle, timezone;
  final double lat, lng;
  final CalculationParameters params;
  const AppLocation({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.timezone,
    required this.lat,
    required this.lng,
    required this.params,
  });
}

final locations = <AppLocation>[
  AppLocation(
    id: 'silchar', name: 'বাঁশকান্দি / শিলচর', subtitle: 'কাছাড়, আসাম, ভারত',
    timezone: 'Asia/Kolkata', lat: 24.8333, lng: 92.7789, params: _silcharParams,
  ),
  AppLocation(
    id: 'salmiya', name: 'সালমিয়া / হাওয়ালি', subtitle: 'কুয়েত',
    timezone: 'Asia/Kuwait', lat: 29.3333, lng: 48.0833, params: _kuwaitParams,
  ),
];

class BaskandiAzanApp extends StatelessWidget {
  const BaskandiAzanApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'বাঁশকান্দি মাদ্রাসা আযান',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6F4A8E))),
    home: const HomePage(),
  );
}

class PrayerItem {
  final String keyName, title;
  final DateTime time;
  PrayerItem(this.keyName, this.title, this.time);
}

class _HomePageState extends State<HomePage> {
  AppLocation _location = locations.first;
  double? _gpsLat, _gpsLng;
  String? _gpsTimezone;
  late DateTime _now;
  late List<PrayerItem> _prayers;
  Timer? _ticker;
  bool _loading = true;
  bool _autoGps = false;
  final AudioPlayer _audio = AudioPlayer();

  final Map<String, bool> _enabled = {'fajr': true, 'dhuhr': true, 'asr': true, 'maghrib': true, 'isha': true};
  final Map<String, int> _offset = {'fajr': 0, 'dhuhr': 0, 'asr': 0, 'maghrib': 0, 'isha': 0};

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _load();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final id = p.getString('location') ?? 'silchar';
    _location = locations.firstWhere((x) => x.id == id, orElse: () => locations.first);
    _autoGps = p.getBool('auto_gps') ?? false;
    for (final k in _enabled.keys) {
      _enabled[k] = p.getBool('on_$k') ?? true;
      _offset[k] = p.getInt('off_$k') ?? 0;
    }
    if (_autoGps) await _useGps(showMessage: false);
    _calculate();
    if (mounted) setState(() => _loading = false);
    await _reschedule();
  }

  void _calculate() {
    final lat = _gpsLat ?? _location.lat;
    final lng = _gpsLng ?? _location.lng;
    final params = _gpsLat != null ? _paramsForGps() : _location.params;
    final c = Coordinates(lat, lng);
    final d = DateComponents(_now.year, _now.month, _now.day);
    final pt = PrayerTimes(c, d, params);
    _prayers = [
      PrayerItem('fajr', 'ফজর', pt.fajr), PrayerItem('dhuhr', 'যোহর', pt.dhuhr),
      PrayerItem('asr', 'আসর', pt.asr), PrayerItem('maghrib', 'মাগরিব', pt.maghrib), PrayerItem('isha', 'ইশা', pt.isha),
    ];
  }

  CalculationParameters _paramsForGps() {
    // ভারতের জন্য Karachi/Hanafi, কুয়েত/মধ্যপ্রাচ্যের জন্য Umm Al-Qura।
    final zone = _gpsTimezone ?? '';
    if (zone == 'Asia/Kolkata') return _silcharParams;
    if (zone == 'Asia/Kuwait') return _kuwaitParams;
    return CalculationMethod.karachi.getParameters()..madhab = Madhab.hanafi;
  }

  String get _activeTimezone => _gpsLat != null ? (_gpsTimezone ?? 'UTC') : _location.timezone;
  String get _activeName => _gpsLat != null ? 'বর্তমান GPS অবস্থান' : _location.name;
  String get _activeSubtitle => _gpsLat != null
      ? '${_gpsLat!.toStringAsFixed(4)}, ${_gpsLng!.toStringAsFixed(4)} • $_activeTimezone'
      : '${_location.subtitle} • ${_location.timezone}';

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('location', _location.id);
    await p.setBool('auto_gps', _autoGps);
    for (final k in _enabled.keys) {
      await p.setBool('on_$k', _enabled[k]!);
      await p.setInt('off_$k', _offset[k]!);
    }
  }

  Future<void> _reschedule() async {
    _calculate();
    final items = <Map<String, dynamic>>[];
    final lat = _gpsLat ?? _location.lat;
    final lng = _gpsLng ?? _location.lng;
    final params = _gpsLat != null ? _paramsForGps() : _location.params;
    final c = Coordinates(lat, lng);

    for (int day = 0; day < 7; day++) {
      final date = DateTime(_now.year, _now.month, _now.day + day);
      final pt = PrayerTimes(c, DateComponents(date.year, date.month, date.day), params);
      final dayPrayers = [
        PrayerItem('fajr', 'ফজর', pt.fajr), PrayerItem('dhuhr', 'যোহর', pt.dhuhr),
        PrayerItem('asr', 'আসর', pt.asr), PrayerItem('maghrib', 'মাগরিব', pt.maghrib), PrayerItem('isha', 'ইশা', pt.isha),
      ];
      for (final pr in dayPrayers) {
        if (_enabled[pr.keyName] != true) continue;
        items.add({'title': pr.title, 'time': pr.time.add(Duration(minutes: _offset[pr.keyName]!)), 'type': 'azan'});
      }
      // সেহরি: ফজরের ১০ মিনিট আগে। ইফতার প্রস্তুতি: মাগরিবের ১ মিনিট আগে।
      items.add({'title': 'সেহরি শেষ হতে ১০ মিনিট বাকি', 'time': pt.fajr.subtract(const Duration(minutes: 10)), 'type': 'reminder'});
      items.add({'title': 'ইফতারের জন্য ১ মিনিট বাকি', 'time': pt.maghrib.subtract(const Duration(minutes: 1)), 'type': 'reminder'});
    }
    await AlarmService.scheduleWeek(items: items, locationName: _activeName, timezoneName: _activeTimezone);
  }

  Future<void> _useGps({bool showMessage = true}) async {
    try {
      if (!await Geolocator.isLocationServiceEnabled()) {
        if (showMessage) _message('ফোনের GPS/লোকেশন চালু করুন।');
        return;
      }
      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied || permission == LocationPermission.deniedForever) {
        if (showMessage) _message('লোকেশন অনুমতি দেওয়া হয়নি।');
        return;
      }
      final pos = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high));
      _gpsLat = pos.latitude; _gpsLng = pos.longitude;
      _gpsTimezone = await _deviceTimezone();
      _autoGps = true;
      _calculate();
      await _save();
      await _reschedule();
      if (mounted) setState(() {});
      if (showMessage) _message('GPS লোকেশন অনুযায়ী সময় আপডেট হয়েছে।');
    } catch (e) {
      if (showMessage) _message('লোকেশন নেওয়া যায়নি। আবার চেষ্টা করুন।');
    }
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  String _clock(DateTime t) => DateFormat('h:mm a').format(t).toLowerCase();

  PrayerItem? _nextPrayer() {
    for (final p in _prayers) {
      final t = p.time.add(Duration(minutes: _offset[p.keyName]!));
      if (t.isAfter(_now)) return PrayerItem(p.keyName, p.title, t);
    }
    return null;
  }

  String _countdown() {
    final n = _nextPrayer();
    if (n == null) return 'পরবর্তী ওয়াক্ত আগামীকাল';
    final d = n.time.difference(_now);
    return '${d.inHours.toString().padLeft(2, '0')}:${(d.inMinutes % 60).toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';
  }

  @override
  void dispose() { _ticker?.cancel(); _audio.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    _calculate();
    final next = _nextPrayer();
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Color(0xFF2F2143), Color(0xFF8D63AD)])),
        child: SafeArea(child: Column(children: [
          _header(), const SizedBox(height: 4),
          Text(_countdown(), style: const TextStyle(color: Colors.white, fontSize: 62, fontWeight: FontWeight.w300)),
          Text(next == null ? 'আজকের সব ওয়াক্ত সম্পন্ন' : 'পরবর্তী: ${next.title}', style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
          const SizedBox(height: 14),
          Text(DateFormat('d MMMM, y', 'bn').format(_now), style: const TextStyle(color: Colors.white, fontSize: 22)),
          const SizedBox(height: 8), Expanded(child: _prayerList()),
        ])),
      ),
    );
  }

  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(18, 10, 8, 4),
    child: Row(children: [
      const Icon(Icons.mosque, color: Colors.white, size: 46), const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
        Text('বাঁশকান্দি মাদ্রাসা আযান', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
        Text('আযান ও নামাজের সময়সূচি', style: TextStyle(color: Colors.white70, fontSize: 12)),
      ])),
      PopupMenuButton<String>(icon: const Icon(Icons.location_on, color: Colors.white, size: 30), onSelected: (id) async {
        _gpsLat = null; _gpsLng = null; _gpsTimezone = null; _autoGps = false;
        _location = locations.firstWhere((x) => x.id == id); _calculate(); await _save(); await _reschedule(); if (mounted) setState(() {});
      }, itemBuilder: (_) => locations.map((x) => PopupMenuItem(value: x.id, child: Text(x.name))).toList()),
      IconButton(icon: const Icon(Icons.my_location, color: Colors.white, size: 27), tooltip: 'GPS', onPressed: () => _useGps()),
      IconButton(icon: const Icon(Icons.settings, color: Colors.white, size: 29), onPressed: _settings),
    ]),
  );

  Widget _prayerList() => ListView.builder(
    padding: const EdgeInsets.only(top: 4), itemCount: _prayers.length,
    itemBuilder: (_, i) { final p = _prayers[i]; final adjusted = p.time.add(Duration(minutes: _offset[p.keyName]!)); final isNext = _nextPrayer()?.keyName == p.keyName;
      return Container(margin: const EdgeInsets.symmetric(vertical: 1), padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 17), color: isNext ? Colors.white : Colors.white.withOpacity(.08), child: Row(children: [
        Icon(Icons.access_time, color: isNext ? Colors.black87 : Colors.white70), const SizedBox(width: 18),
        Expanded(child: Text(p.title, style: TextStyle(color: isNext ? Colors.black : Colors.white, fontSize: 24, fontWeight: FontWeight.w500))),
        Text(_clock(adjusted), style: TextStyle(color: isNext ? Colors.black : Colors.white, fontSize: 24, fontWeight: FontWeight.w600)), const SizedBox(width: 10),
        Icon(_enabled[p.keyName]! ? Icons.notifications_active : Icons.notifications_off, color: isNext ? Colors.black54 : Colors.white70),
      ]));
    });

  Future<void> _settings() async {
    await showModalBottomSheet(context: context, isScrollControlled: true, builder: (_) => StatefulBuilder(builder: (ctx, setSheet) => SafeArea(child: Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 24), child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Center(child: Text('আযান ও সময়ের সেটিংস', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
        const SizedBox(height: 10), ListTile(leading: const Icon(Icons.location_on), title: Text(_activeName), subtitle: Text(_activeSubtitle)),
        SwitchListTile(title: const Text('GPS দিয়ে স্বয়ংক্রিয় লোকেশন'), value: _autoGps, onChanged: (v) async { setSheet(() => _autoGps = v); if (v) await _useGps(showMessage: false); else { _gpsLat = null; _gpsLng = null; _gpsTimezone = null; await _save(); await _reschedule(); setState(() {}); } }),
        const Divider(height: 18),
        ..._prayers.map((p) => ListTile(title: Text(p.title, style: const TextStyle(fontSize: 18)), subtitle: Text('সমন্বয়: ${_offset[p.keyName]! >= 0 ? '+' : ''}${_offset[p.keyName]} মিনিট'), leading: IconButton(icon: const Icon(Icons.remove_circle_outline), onPressed: () async { setSheet(() => _offset[p.keyName] = (_offset[p.keyName]! - 1).clamp(-10, 10)); await _save(); await _reschedule(); setState(() {}); }), trailing: Row(mainAxisSize: MainAxisSize.min, children: [Switch(value: _enabled[p.keyName]!, onChanged: (v) async { setSheet(() => _enabled[p.keyName] = v); await _save(); await _reschedule(); setState(() {}); }), IconButton(icon: const Icon(Icons.add_circle_outline), onPressed: () async { setSheet(() => _offset[p.keyName] = (_offset[p.keyName]! + 1).clamp(-10, 10)); await _save(); await _reschedule(); setState(() {}); })]))),
        const Divider(),
        ListTile(leading: const Icon(Icons.alarm), title: const Text('সেহরি সতর্কতা'), subtitle: const Text('ফজরের ১০ মিনিট আগে স্বয়ংক্রিয় বিজ্ঞপ্তি'), trailing: const Icon(Icons.check_circle)),
        ListTile(leading: const Icon(Icons.restaurant), title: const Text('ইফতার সতর্কতা'), subtitle: const Text('মাগরিবের ১ মিনিট আগে স্বয়ংক্রিয় বিজ্ঞপ্তি'), trailing: const Icon(Icons.check_circle)),
        ListTile(leading: const Icon(Icons.music_note), title: const Text('আযান অডিও পরীক্ষা'), subtitle: const Text('নিজস্ব অনুমোদিত azan.mp3 যোগ করলে এখানে পরীক্ষা করা যাবে'), trailing: IconButton(icon: const Icon(Icons.play_arrow), onPressed: () async { try { await _audio.play(AssetSource('audio/azan.mp3')); } catch (_) { _message('আযান অডিও পাওয়া যায়নি। assets/audio/azan.mp3 যোগ করুন।'); } })),
        const SizedBox(height: 8), const Text('নোট: স্থানীয় মসজিদের মাইক/ইমামের সময়ের সঙ্গে মিলিয়ে প্রয়োজন হলে ±১০ মিনিট সমন্বয় করুন।', style: TextStyle(color: Colors.grey)),
      ])),
    ))));
  }
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState() => _HomePageState(); }
