import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class AlarmService {
  static final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  static const _azanChannel = AndroidNotificationChannel(
    'azan_channel_v2',
    'আযান',
    description: 'পাঁচ ওয়াক্তের আযান ও নামাজের সময়ের বিজ্ঞপ্তি',
    importance: Importance.max,
    playSound: true,
    sound: RawResourceAndroidNotificationSound('azan'),
  );

  static const _reminderChannel = AndroidNotificationChannel(
    'fasting_reminder_v2',
    'সেহরি ও ইফতার',
    description: 'সেহরি ও ইফতারের আগাম সতর্কতা',
    importance: Importance.high,
    playSound: true,
  );

  static Future<void> initialize({String? localTimezone}) async {
    tzdata.initializeTimeZones();
    if (localTimezone != null) {
      try {
        tz.setLocalLocation(tz.getLocation(localTimezone));
      } catch (_) {}
    }

    const android = AndroidInitializationSettings('@drawable/ic_launcher');
    const settings = InitializationSettings(android: android);

    await plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: (_) {},
    );

    final androidPlugin = plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidPlugin?.createNotificationChannel(_azanChannel);
    await androidPlugin?.createNotificationChannel(_reminderChannel);
    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
  }

  static Future<void> cancelAll() => plugin.cancelAll();

  static Future<void> scheduleWeek({
    required List<Map<String, dynamic>> items,
    required String locationName,
    required String timezoneName,
  }) async {
    await plugin.cancelAll();
    final location = tz.getLocation(timezoneName);
    var id = 1000;

    for (final item in items) {
      final dt = item['time'] as DateTime;
      final scheduled = tz.TZDateTime(
        location,
        dt.year,
        dt.month,
        dt.day,
        dt.hour,
        dt.minute,
        dt.second,
      );
      if (!scheduled.isAfter(tz.TZDateTime.now(location))) continue;

      final isReminder = item['type'] == 'reminder';
      final title = isReminder
          ? 'বাঁশকান্দি মাদ্রাসা আযান • ${item['title']}'
          : 'বাঁশকান্দি মাদ্রাসা আযান';

      await plugin.zonedSchedule(
        id++,
        title,
        '${item['title']} • $locationName',
        scheduled,
        NotificationDetails(
          android: AndroidNotificationDetails(
            isReminder ? _reminderChannel.id : _azanChannel.id,
            isReminder ? _reminderChannel.name : _azanChannel.name,
            channelDescription: isReminder
                ? _reminderChannel.description
                : _azanChannel.description,
            importance: isReminder ? Importance.high : Importance.max,
            priority: isReminder ? Priority.high : Priority.max,
            playSound: true,
            enableVibration: true,
            sound: isReminder
                ? null
                : const RawResourceAndroidNotificationSound('azan'),
            category: AndroidNotificationCategory.alarm,
          ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    }
  }
}
