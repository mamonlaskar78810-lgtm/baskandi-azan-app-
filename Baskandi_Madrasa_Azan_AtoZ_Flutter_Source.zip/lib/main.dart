import 'dart:async';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:adhan/adhan.dart';
import 'services/alarm_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AlarmService.initialize();
  runApp(const BaskandiAzanApp());
}

class AppLocation {
  final String id, name, subtitle, timezone;
  final double lat, lng;
  final CalculationParameters params;

  const AppLocation({
    required this.id,
    required this.name,
    required this.subtitle,
    required this.timezone,
    required this.lat,
    required this.lng,
    required this.params,
  });
}

final locations = <AppLocation>[
  AppLocation(
    id: 'silchar',
    name: 'বাঁশকান্দি / শিলচর',
    subtitle: 'কাছাড়, আসাম, ভারত',
    timezone: 'Asia/Kolkata',
    lat: 24.8333,
    lng: 92.7789,
    params: _silcharParams,
  ),
  AppLocation(
    id: 'salmiya',
    name: 'সালমিয়া / হাওয়ালি',
    subtitle: 'কুয়েত',
    timezone: 'Asia/Kuwait',
    lat: 29.3333,
    lng: 48.0833,
    params: _kuwaitParams,
  ),
];

final CalculationParameters _silcharParams =
    CalculationMethod.karachi.getParameters()
      ..madhab = Madhab.hanafi;

final CalculationParameters _kuwaitParams =
    CalculationMethod.umm_al_qura.getParameters()
      ..madhab = Madhab.shafi;

class BaskandiAzanApp extends StatelessWidget {
  const BaskandiAzanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'বাঁশকান্দি মাদ্রাসা আযান',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'sans',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6F4A8E)),
      ),
      home: const HomePage(),
    );
  }
}

class PrayerItem {
  final String keyName, title;
  final DateTime time;
  PrayerItem(this.keyName, this.title, this.time);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  AppLocation _location = locations.first;
  late DateTime _now;
  late List<PrayerItem> _prayers;
  Timer? _ticker;

  final Map<String, bool> _enabled = {
    'fajr': true, 'dhuhr': true, 'asr': true, 'maghrib': true, 'isha': true,
  };

  final Map<String, int> _offset = {
    'fajr': 0, 'dhuhr': 0, 'asr': 0, 'maghrib': 0, 'isha': 0,
  };

  @override
  void initState() {
    super.initState();
    _now = DateTime.now();
    _load();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() => _now = DateTime.now());
    });
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final id = p.getString('location') ?? 'silchar';
    _location = locations.firstWhere((x) => x.id == id, orElse: () => locations.first);
    for (final k in _enabled.keys) {
      _enabled[k] = p.getBool('on_$k') ?? true;
      _offset[k] = p.getInt('off_$k') ?? 0;
    }
    _calculate();
    if (mounted) setState(() {});
    await _reschedule();
  }

  void _calculate() {
    final c = Coordinates(_location.lat, _location.lng);
    final d = DateComponents(_now.year, _now.month, _now.day);
    final pt = PrayerTimes(c, d, _location.params);
    _prayers = [
      PrayerItem('fajr', 'ফজর', pt.fajr),
      PrayerItem('dhuhr', 'যোহর', pt.dhuhr),
      PrayerItem('asr', 'আসর', pt.asr),
      PrayerItem('maghrib', 'মাগরিব', pt.maghrib),
      PrayerItem('isha', 'ইশা', pt.isha),
    ];
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('location', _location.id);
    for (final k in _enabled.keys) {
      await p.setBool('on_$k', _enabled[k]!);
      await p.setInt('off_$k', _offset[k]!);
    }
  }

  Future<void> _reschedule() async {
    _calculate();

    // আগামী ৭ দিনের প্রতিটি ওয়াক্ত আলাদা করে schedule করা হয়।
    // তাই প্রতিদিনের astronomical prayer-time পরিবর্তনও অ্যালার্মে প্রতিফলিত হয়।
    final upcoming = <Map<String, dynamic>>[];
    final c = Coordinates(_location.lat, _location.lng);

    for (int day = 0; day < 7; day++) {
      final date = DateTime(_now.year, _now.month, _now.day + day);
      final dc = DateComponents(date.year, date.month, date.day);
      final pt = PrayerTimes(c, dc, _location.params);

      final dayPrayers = [
        PrayerItem('fajr', 'ফজর', pt.fajr),
        PrayerItem('dhuhr', 'যোহর', pt.dhuhr),
        PrayerItem('asr', 'আসর', pt.asr),
        PrayerItem('maghrib', 'মাগরিব', pt.maghrib),
        PrayerItem('isha', 'ইশা', pt.isha),
      ];

      for (final p in dayPrayers) {
        if (_enabled[p.keyName] != true) continue;
        final adjusted = p.time.add(Duration(minutes: _offset[p.keyName]!));
        upcoming.add({
          'key': p.keyName,
          'title': p.title,
          'time': adjusted,
        });
      }
    }

    await AlarmService.scheduleWeekly(
      prayers: upcoming,
      locationName: _location.name,
      timezoneName: _location.timezone,
    );
  }

  String _clock(DateTime t) => DateFormat('h:mm a').format(t).toLowerCase();

  PrayerItem? _nextPrayer() {
    for (final p in _prayers) {
      final t = p.time.add(Duration(minutes: _offset[p.keyName]!));
      if (t.isAfter(_now)) return PrayerItem(p.keyName, p.title, t);
    }
    return null;
  }

  String _countdown() {
    final n = _nextPrayer();
    if (n == null) return 'পরবর্তী ওয়াক্ত আগামীকাল';
    final d = n.time.difference(_now);
    final h = d.inHours.toString().padLeft(2, '0');
    final m = (d.inMinutes % 60).toString().padLeft(2, '0');
    final s = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    _calculate();
    final next = _nextPrayer();
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Color(0xFF2F2143), Color(0xFF8D63AD)],
          ),
        ),
        child: SafeArea(
          child: Column(
            children: [
              _header(),
              const SizedBox(height: 6),
              Text(_countdown(),
                  style: const TextStyle(color: Colors.white, fontSize: 64, fontWeight: FontWeight.w300)),
              Text(next == null ? 'আজকের সব ওয়াক্ত সম্পন্ন' : 'পরবর্তী: ${next.title}',
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600)),
              const SizedBox(height: 16),
              Text(DateFormat('d MMMM, y', 'bn').format(_now),
                  style: const TextStyle(color: Colors.white, fontSize: 22)),
              const SizedBox(height: 8),
              Expanded(child: _prayerList()),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(18, 12, 12, 4),
      child: Row(
        children: [
          const Icon(Icons.mosque, color: Colors.white, size: 48),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
              Text('বাঁশকান্দি মাদ্রাসা আযান',
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
              Text('দারুল উলূম বাঁশকান্দি • আযান ও নামাজের সময়',
                  style: TextStyle(color: Colors.white70, fontSize: 12)),
            ]),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.location_on, color: Colors.white, size: 30),
            onSelected: (id) async {
              setState(() {
                _location = locations.firstWhere((x) => x.id == id);
                _calculate();
              });
              await _save();
              await _reschedule();
            },
            itemBuilder: (_) => locations.map((x) => PopupMenuItem(
              value: x.id,
              child: Text(x.name),
            )).toList(),
          ),
          IconButton(
            icon: const Icon(Icons.settings, color: Colors.white, size: 30),
            onPressed: _settings,
          ),
        ],
      ),
    );
  }

  Widget _prayerList() {
    return ListView.builder(
      padding: const EdgeInsets.only(top: 4),
      itemCount: _prayers.length,
      itemBuilder: (_, i) {
        final p = _prayers[i];
        final adjusted = p.time.add(Duration(minutes: _offset[p.keyName]!));
        final isNext = _nextPrayer()?.keyName == p.keyName;
        return Container(
          margin: const EdgeInsets.symmetric(vertical: 1),
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 17),
          color: isNext ? Colors.white : Colors.white.withOpacity(.08),
          child: Row(
            children: [
              Icon(Icons.access_time, color: isNext ? Colors.black87 : Colors.white70),
              const SizedBox(width: 18),
              Expanded(child: Text(p.title,
                  style: TextStyle(color: isNext ? Colors.black : Colors.white, fontSize: 24, fontWeight: FontWeight.w500))),
              Text(_clock(adjusted),
                  style: TextStyle(color: isNext ? Colors.black : Colors.white, fontSize: 24, fontWeight: FontWeight.w600)),
              const SizedBox(width: 12),
              Icon(_enabled[p.keyName]! ? Icons.notifications_active : Icons.notifications_off,
                  color: isNext ? Colors.black54 : Colors.white70),
            ],
          ),
        );
      },
    );
  }

  Future<void> _settings() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(builder: (ctx, setSheet) {
        return SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Center(child: Text('আযান ও সময়ের সেটিংস',
                      style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold))),
                  const SizedBox(height: 12),
                  Text(_location.name, style: const TextStyle(fontSize: 16)),
                  Text('${_location.subtitle} • ${_location.timezone}',
                      style: const TextStyle(color: Colors.grey)),
                  const Divider(height: 28),
                  ..._prayers.map((p) => ListTile(
                    title: Text(p.title, style: const TextStyle(fontSize: 18)),
                    subtitle: Text('সমন্বয়: ${_offset[p.keyName]! >= 0 ? '+' : ''}${_offset[p.keyName]} মিনিট'),
                    leading: IconButton(
                      icon: const Icon(Icons.remove_circle_outline),
                      onPressed: () {
                        setSheet(() => _offset[p.keyName] = (_offset[p.keyName]! - 1).clamp(-10, 10));
                        _save();
                        _reschedule();
                        setState(() {});
                      },
                    ),
                    trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                      Switch(
                        value: _enabled[p.keyName]!,
                        onChanged: (v) {
                          setSheet(() => _enabled[p.keyName] = v);
                          _save();
                          _reschedule();
                          setState(() {});
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () {
                          setSheet(() => _offset[p.keyName] = (_offset[p.keyName]! + 1).clamp(-10, 10));
                          _save();
                          _reschedule();
                          setState(() {});
                        },
                      ),
                    ]),
                  )),
                  const Divider(),
                  ListTile(
                    leading: const Icon(Icons.alarm),
                    title: const Text('সেহরি সতর্কতা'),
                    subtitle: const Text('সেহরির শেষ সময়ের ১০ মিনিট আগে'),
                    trailing: const Icon(Icons.check_circle),
                  ),
                  ListTile(
                    leading: const Icon(Icons.restaurant),
                    title: const Text('ইফতার সতর্কতা'),
                    subtitle: const Text('মাগরিবের ১ মিনিট আগে'),
                    trailing: const Icon(Icons.check_circle),
                  ),
                  const SizedBox(height: 8),
                  const Text('নোট: স্থানীয় মসজিদের মাইক/ইমামের সময়ের সঙ্গে মিলিয়ে প্রয়োজন হলে সমন্বয় করুন।',
                      style: TextStyle(color: Colors.grey)),
                ],
              ),
            ),
          ),
        );
      }),
    );
  }
}
