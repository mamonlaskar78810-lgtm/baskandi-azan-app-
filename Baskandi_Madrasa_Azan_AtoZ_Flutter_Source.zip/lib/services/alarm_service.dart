import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class AlarmService {
  static final FlutterLocalNotificationsPlugin plugin =
      FlutterLocalNotificationsPlugin();

  static Future<void> initialize() async {
    tzdata.initializeTimeZones();

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);

    await plugin.initialize(
      settings,
      onDidReceiveNotificationResponse: (response) {},
    );

    final androidPlugin = plugin
        .resolvePlatformSpecificImplementation<
            AndroidFlutterLocalNotificationsPlugin>();

    await androidPlugin?.requestNotificationsPermission();
    await androidPlugin?.requestExactAlarmsPermission();
  }

  static Future<void> scheduleWeekly({
    required List<Map<String, dynamic>> prayers,
    required String locationName,
    required String timezoneName,
  }) async {
    await plugin.cancelAll();

    final location = tz.getLocation(timezoneName);
    int id = 1000;

    for (final p in prayers) {
      final DateTime dt = p['time'] as DateTime;

      // Adhan-এর wall-clock time-কে নির্বাচিত শহরের timezone-এ বসানো হচ্ছে।
      final scheduled = tz.TZDateTime(
        location,
        dt.year,
        dt.month,
        dt.day,
        dt.hour,
        dt.minute,
        dt.second,
      );

      if (scheduled.isBefore(tz.TZDateTime.now(location))) continue;

      await plugin.zonedSchedule(
        id++,
        'বাঁশকান্দি মাদ্রাসা আযান',
        '${p['title']} এর সময় হয়েছে • $locationName',
        scheduled,
        const NotificationDetails(
          android: AndroidNotificationDetails(
            'azan_channel',
            'আযান',
            channelDescription: 'নামাজের সময় ও আযানের বিজ্ঞপ্তি',
            importance: Importance.max,
            priority: Priority.max,
            playSound: true,
            enableVibration: true,
        ),
        ),
        androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
        uiLocalNotificationDateInterpretation:
            UILocalNotificationDateInterpretation.absoluteTime,
      );
    }
  }
}
