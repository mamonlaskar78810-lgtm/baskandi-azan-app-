package com.example.silchar_salmiya_azan
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
