import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../services/azan_service.dart';
import '../services/notification_service.dart';

class HomeScreen extends StatefulWidget {
  final NotificationService notificationService;
  const HomeScreen({super.key,required this.notificationService});
  @override State<HomeScreen> createState()=>_HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>{
  final service=AzanService();
  AppLocation location=AppLocation.silchar;
  late List<PrayerRow> rows;
  Map<String,bool> enabled={'fajr':true,'dhuhr':true,'asr':true,'maghrib':true,'isha':true};
  Map<String,int> adj={'fajr':0,'dhuhr':0,'asr':0,'maghrib':0,'isha':0};
  LocationProfile get profile=>AzanService.profile(location);

  @override void initState(){super.initState();_load();}
  Future<void> _load() async{
    final p=await SharedPreferences.getInstance();
    location=p.getString('location')=='salmiya'?AppLocation.salmiya:AppLocation.silchar;
    for(final k in enabled.keys){enabled[k]=p.getBool('on_$k')??true;adj[k]=p.getInt('adj_$k')??0;}
    _refresh();await _schedule();
  }
  void _refresh(){rows=service.times(profile,DateTime.now(),adj);if(mounted)setState((){});}
  Future<void> _schedule()=>widget.notificationService.scheduleLocation(
    location:profile,service:service,enabled:enabled,adjustments:adj,days:7);
  Future<void> _save() async{
    final p=await SharedPreferences.getInstance();
    await p.setString('location',location==AppLocation.silchar?'silchar':'salmiya');
    for(final k in enabled.keys){await p.setBool('on_$k',enabled[k]!);await p.setInt('adj_$k',adj[k]!);}
    _refresh();await _schedule();
  }
  String fmt(DateTime t)=>DateFormat('hh:mm a').format(t);

  Future<void> _location() async{
    final x=await showDialog<AppLocation>(context:context,builder:(_)=>SimpleDialog(
      title:const Text('স্থান নির্বাচন করুন'),
      children:[
        SimpleDialogOption(onPressed:()=>Navigator.pop(context,AppLocation.silchar),
          child:const Text('🇮🇳 শিলচর / কাছাড়')),
        SimpleDialogOption(onPressed:()=>Navigator.pop(context,AppLocation.salmiya),
          child:const Text('🇰🇼 সালমিয়া / হাওয়ালি'))]));
    if(x!=null){location=x;await _save();}
  }

  Future<void> _adjust(String key) async{
    int value=adj[key]??0;
    await showDialog(context:context,builder:(_)=>StatefulBuilder(
      builder:(c,setD)=>AlertDialog(
        title:Text('$key সময় সমন্বয়'),
        content:Column(mainAxisSize:MainAxisSize.min,children:[
          Text('${value>=0?'+':''}$value মিনিট'),
          Slider(min:-10,max:10,divisions:20,value:value.toDouble(),
            onChanged:(v)=>setD(()=>value=v.round()))]),
        actions:[
          TextButton(onPressed:()=>Navigator.pop(c),child:const Text('বাতিল')),
          FilledButton(onPressed:(){adj[key]=value;Navigator.pop(c);},
            child:const Text('সংরক্ষণ'))])));
    await _save();
  }

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:const Text('🕌 নামাজ ও আযান'),
      actions:[IconButton(onPressed:_location,icon:const Icon(Icons.location_on))]),
    body:RefreshIndicator(onRefresh:_save,child:ListView(padding:const EdgeInsets.all(14),children:[
      Card(child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
        Text(profile.name,style:const TextStyle(fontSize:23,fontWeight:FontWeight.bold)),
        Text(profile.country),Text('${profile.lat}° • ${profile.lon}°'),
        Text(profile.timezone),
        Text(location==AppLocation.silchar?'Karachi Method • Hanafi':'Umm Al-Qura • Kuwait'),
      ]))),
      ...rows.map((p)=>Card(child:ListTile(
        leading:Icon(p.prayer?Icons.mosque:Icons.wb_sunny_outlined),
        title:Text(p.name),
        subtitle:p.prayer?Text('সমন্বয়: ${adj[p.key]!>=0?'+':''}${adj[p.key]} মিনিট'):null,
        trailing:p.prayer?Row(mainAxisSize:MainAxisSize.min,children:[
          Text(fmt(p.time),style:const TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
          Switch(value:enabled[p.key]!,onChanged:(v)async{enabled[p.key]=v;await _save();})])
          :Text(fmt(p.time)),
        onLongPress:p.prayer?()=>_adjust(p.key):null))),
      if(location==AppLocation.silchar) const Card(child:Padding(
        padding:EdgeInsets.all(14),child:Text(
          '১৬ আগস্ট ২০২৬-এর শিলচর বড় মসজিদ reference: '
          'ফজর 03:56 • যোহর 11:47 • আসর 04:24 • মাগরিব 06:16 • ইশা 07:36\n\n'
          'এগুলো আনুমানিক reference data; স্থায়ী সারা বছরের সময় নয়.'))),
      const Padding(padding:EdgeInsets.all(12),child:Text(
        'সালাতের ক্ষেত্রে স্থানীয় মসজিদের মাইকের আযান ও যাচাইকৃত তালিকাকে অগ্রাধিকার দিন। '
        'গাণিতিক হিসাব কয়েক মিনিট আলাদা হতে পারে.',textAlign:TextAlign.center))
    ])));
}
