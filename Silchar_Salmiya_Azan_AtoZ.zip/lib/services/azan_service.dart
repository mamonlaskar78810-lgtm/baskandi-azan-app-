import 'package:adhan/adhan.dart';

enum AppLocation { silchar, salmiya }

class LocationProfile {
  final AppLocation id;
  final String name, country, timezone;
  final double lat, lon;
  final CalculationParameters params;
  const LocationProfile({required this.id, required this.name, required this.country,
    required this.timezone, required this.lat, required this.lon, required this.params});
}

class PrayerRow {
  final String key, name;
  final DateTime time;
  final bool prayer;
  PrayerRow(this.key, this.name, this.time, {this.prayer = true});
}

class AzanService {
  static LocationProfile get silchar {
    final p = CalculationMethod.karachi.getParameters();
    p.madhab = Madhab.hanafi;
    return LocationProfile(id: AppLocation.silchar, name: 'শিলচর / কাছাড়',
      country: 'ভারত', timezone: 'Asia/Kolkata', lat: 24.8333, lon: 92.7789, params: p);
  }

  static LocationProfile get salmiya {
    final p = CalculationMethod.umm_al_qura.getParameters();
    return LocationProfile(id: AppLocation.salmiya, name: 'সালমিয়া / হাওয়ালি',
      country: 'কুয়েত', timezone: 'Asia/Kuwait', lat: 29.3333, lon: 48.0833, params: p);
  }

  static LocationProfile profile(AppLocation id) =>
      id == AppLocation.silchar ? silchar : salmiya;

  List<PrayerRow> times(LocationProfile loc, DateTime date, Map<String,int> adj) {
    final pt = PrayerTimes(Coordinates(loc.lat, loc.lon),
      DateComponents(date.year, date.month, date.day), loc.params);
    DateTime a(String k, DateTime d) => d.add(Duration(minutes: adj[k] ?? 0));
    return [
      PrayerRow('fajr','ফজর',a('fajr',pt.fajr)),
      PrayerRow('sunrise','সূর্যোদয়',a('sunrise',pt.sunrise),prayer:false),
      PrayerRow('dhuhr','যোহর',a('dhuhr',pt.dhuhr)),
      PrayerRow('asr','আসর (হানাফি)',a('asr',pt.asr)),
      PrayerRow('maghrib','মাগরিব',a('maghrib',pt.maghrib)),
      PrayerRow('isha','ইশা',a('isha',pt.isha)),
    ];
  }
  List<PrayerRow> prayers(LocationProfile l, DateTime d, Map<String,int> a) =>
      times(l,d,a).where((x)=>x.prayer).toList();
}
