import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;
import 'azan_service.dart';

class NotificationService {
  final plugin = FlutterLocalNotificationsPlugin();

  Future<void> initialize() async {
    await plugin.initialize(const InitializationSettings(
      android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  }

  Future<void> requestPermissions() async {
    final a = plugin.resolvePlatformSpecificImplementation<
      AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    await a?.requestExactAlarmsPermission();
  }

  NotificationDetails get details => const NotificationDetails(
    android: AndroidNotificationDetails('azan_channel','আজান ও নামাজ',
      channelDescription:'নামাজের ওয়াক্তের বিজ্ঞপ্তি',
      importance:Importance.max, priority:Priority.high,
      playSound:true, enableVibration:true));

  Future<void> clear() => plugin.cancelAll();

  Future<void> schedule(int id,String title,String body,DateTime dt) async {
    final t=tz.TZDateTime.from(dt,tz.local);
    if(t.isBefore(tz.TZDateTime.now(tz.local))) return;
    await plugin.zonedSchedule(id,title,body,t,details,
      androidScheduleMode:AndroidScheduleMode.exactAllowWhileIdle,
      uiLocalNotificationDateInterpretation:
        UILocalNotificationDateInterpretation.absoluteTime);
  }

  Future<void> scheduleLocation({
    required LocationProfile location, required AzanService service,
    required Map<String,bool> enabled, required Map<String,int> adjustments,
    int days=7}) async {
    await clear();
    final now=DateTime.now();
    for(int d=0;d<days;d++){
      final date=DateTime(now.year,now.month,now.day+d);
      final rows=service.prayers(location,date,adjustments);
      for(int i=0;i<rows.length;i++){
        final p=rows[i];
        if(enabled[p.key]==false) continue;
        await schedule(10000+d*100+i,'🕌 ${p.name}',
          '${location.name} — এখন ${p.name}-এর ওয়াক্ত।',p.time);
      }
      final all=service.times(location,date,adjustments);
      final fajr=all.firstWhere((x)=>x.key=='fajr').time;
      final mag=all.firstWhere((x)=>x.key=='maghrib').time;
      await schedule(20000+d,'🌙 সেহরি শেষ হতে ১০ মিনিট',
        '${location.name} — সেহরি শেষ হওয়ার সময় ঘনিয়ে এসেছে.',
        fajr.subtract(const Duration(minutes:10)));
      await schedule(30000+d,'🌙 ইফতার হতে ১ মিনিট',
        '${location.name} — ইফতারের সময় খুব কাছাকাছি.',
        mag.subtract(const Duration(minutes:1)));
    }
  }
}
