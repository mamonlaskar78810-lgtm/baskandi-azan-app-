import 'package:flutter/material.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'services/azan_service.dart';
import 'services/notification_service.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  tz.initializeTimeZones();
  final n = NotificationService();
  await n.initialize();
  await n.requestPermissions();
  runApp(AzanApp(notificationService: n));
}

class AzanApp extends StatelessWidget {
  final NotificationService notificationService;
  const AzanApp({super.key, required this.notificationService});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'নামাজ ও আযান',
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.green),
    home: HomeScreen(notificationService: notificationService),
  );
}
