এখানে আপনার নিজস্ব বা অনুমোদিত azan.mp3 রাখুন।
Custom notification sound-এর জন্য Android notification channel-এ raw resource sound configure করুন।
