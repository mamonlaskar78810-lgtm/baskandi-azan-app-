# 🕌 নামাজ ও আযান — শিলচর + সালমিয়া

## শিলচর / কাছাড়
Latitude 24.8333, Longitude 92.7789, Asia/Kolkata, Karachi, Hanafi.

## সালমিয়া / হাওয়ালি
Latitude 29.3333, Longitude 48.0833, Asia/Kuwait, Umm Al-Qura.

## ফিচার
- দুই লোকেশন switch
- ৫ ওয়াক্তের দৈনিক সময়
- Hanafi Asr
- প্রতিটি ওয়াক্তের আলাদা ON/OFF
- প্রতিটি ওয়াক্তে -10/+10 মিনিট adjustment
- ৭ দিনের alarm scheduling
- Android notification/exact alarm permission
- reboot receiver
- বাংলা UI
- সেহরি ১০ মিনিট আগে reminder
- ইফতার ১ মিনিট আগে reminder
- ১৬ আগস্ট ২০২৬-এর শিলচর reference timetable

## Reference timetable
শিলচর বড় মসজিদ, ১৬ আগস্ট ২০২৬ (ব্যবহারকারীর দেওয়া আনুমানিক সময়):
ফজর 03:56, যোহর 11:47, আসর 04:24, মাগরিব 06:16, ইশা 07:36.

এগুলো স্থায়ী fixed time নয়। অ্যাপ তারিখ ও location অনুযায়ী astronomical calculation করে দৈনিক সময় তৈরি করে।

## Build
flutter pub get
flutter run
flutter build apk --release

## গুরুত্বপূর্ণ
স্থানীয় মসজিদের verified timetable/মাইকের আযানকে সালাতের জন্য অগ্রাধিকার দিন।
ফোন সম্পূর্ণ power-off অবস্থায় সাধারণ Android app নিজে থেকে বাজতে পারে না; boot-এর পরে alarms reschedule করা যায়।
কিছু ফোনের battery optimization/auto-start policy alarm delivery প্রভাবিত করতে পারে।
